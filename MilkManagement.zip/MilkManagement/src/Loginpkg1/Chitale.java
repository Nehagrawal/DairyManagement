package Loginpkg1;

import java.awt.EventQueue;

import java.sql.*;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JDateChooser;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Font;
import java.awt.Color;



public class Chitale extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField BM;
	private JTextField CM;
	private JTextField Payment;
int bm,cm,bmres,cmres,bal,total,pay;
   myconnect my=new myconnect();
   Connection conn;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Chitale frame = new Chitale();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Chitale() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setBounds(146, 108, 95, 15);
		contentPane.add(lblDate);
		
		JLabel lblBm = new JLabel("Buffalo Mlik");
		lblBm.setBounds(146, 158, 95, 15);
		contentPane.add(lblBm);
		
		JLabel lblCm = new JLabel("Cow Milk");
		lblCm.setBounds(147, 215, 81, 15);
		contentPane.add(lblCm);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setBounds(158, 341, 70, 15);
		contentPane.add(lblTotal);
		
		JLabel lblPayment = new JLabel("Payment");
		lblPayment.setBounds(158, 407, 70, 15);
		contentPane.add(lblPayment);
		
		JLabel lblBalance = new JLabel("Balance");
		lblBalance.setBounds(163, 485, 70, 15);
		contentPane.add(lblBalance);
		
		BM = new JTextField();
		BM.setBounds(326, 155, 114, 21);
		contentPane.add(BM);
		BM.setColumns(10);
		
		CM = new JTextField();
		CM.setBounds(326, 212, 114, 21);
		contentPane.add(CM);
		CM.setColumns(10);
		
		Payment = new JTextField();
		Payment.setBounds(326, 405, 114, 19);
		contentPane.add(Payment);
		Payment.setColumns(10);
	
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("yyyy-MM-dd");
		
		dateChooser.setBounds(326, 104, 100, 19);
		contentPane.add(dateChooser);
		JLabel l_total = new JLabel("");
		l_total.setBounds(348, 359, 114, 15);
		contentPane.add(l_total);
		
		JLabel b_total = new JLabel("");
		b_total.setBounds(326, 508, 114, 15);
		contentPane.add(b_total);
		JButton btnCalculateTotal = new JButton("Calculate total");
		btnCalculateTotal.setBackground(Color.GRAY);
		btnCalculateTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			     

                 bm=Integer.parseInt(BM.getText());
				 cm=Integer.parseInt(CM.getText());
				
				 bmres=bm*40;
				 cmres=cm*30;
				 total=bmres+cmres;
			      l_total.setText(Integer.toString(total));
				
			}
			
		});
		btnCalculateTotal.setBounds(230, 275, 188, 25);
		contentPane.add(btnCalculateTotal);
		
		
		JButton btnCalculateBalance = new JButton("Calculate Balance");
		btnCalculateBalance.setBackground(Color.GRAY);
		btnCalculateBalance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				pay=Integer.parseInt(Payment.getText());
				bal=total-pay;
				b_total.setText(Integer.toString(bal));

			}
		});
		btnCalculateBalance.setBounds(251, 450, 167, 25);
		contentPane.add(btnCalculateBalance);
		
		
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBackground(Color.GRAY);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String query = "insert into Chitale(Date,BM,CM,Total,Payment,Balance)"+"values(?,?,?,?,?,?)";
				
					try {	
					PreparedStatement prep_stmt;
					conn=my.getConn();
					prep_stmt = conn.prepareStatement(query);
					prep_stmt.setString(1,((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());

                  	prep_stmt.setString(2,BM.getText());
					prep_stmt.setString(3, CM.getText());
					prep_stmt.setString(4,Integer.toString(total));
				    prep_stmt.setString(5, Payment.getText());
					 
					prep_stmt.setString(6,Integer.toString(bal));
					 
					prep_stmt.execute();
					
					JOptionPane.showMessageDialog(null,"Added Succesfully");
					conn.close();
				}catch(Exception e) {}
					
					
				
			}

		
		});
		btnAdd.setBounds(197, 535, 117, 25);
		contentPane.add(btnAdd);
		
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
			}
		});
		btnBack.setBounds(390, 535, 117, 25);
		contentPane.add(btnBack);
		
		JLabel lblChitaleMilkDetails = DefaultComponentFactory.getInstance().createTitle("Chitale Milk Details");
		lblChitaleMilkDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblChitaleMilkDetails.setBounds(197, 42, 246, 15);
		contentPane.add(lblChitaleMilkDetails);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel.setBounds(12, 0, 576, 650);
		contentPane.add(lblNewLabel);

	
		
		
	}
}