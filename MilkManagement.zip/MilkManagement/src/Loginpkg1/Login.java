package Loginpkg1;

import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.ImageIcon;

public class Login {

	private JFrame frame;
	private JTextField txtusername;
	private JPasswordField txtpassword;
	private JFrame frmloginsystem;

	/**
	 * Launch the application.
	 */

	
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(50, 50,700, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUsername = new JLabel("User Name :");
		lblUsername.setBounds(212, 291, 104, 40);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setBounds(212, 367, 104, 32);
		frame.getContentPane().add(lblPassword);
		
		txtusername = new JTextField();
		txtusername.setBounds(362, 302, 134, 19);
		frame.getContentPane().add(txtusername);
		txtusername.setColumns(10);
		
		JLabel lblLoginForm = new JLabel("Login Form");
		lblLoginForm.setBounds(302, 212, 104, 32);
		frame.getContentPane().add(lblLoginForm);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(373, 374, 133, 19);
		frame.getContentPane().add(txtpassword);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String password=txtpassword.getText();
			String username=txtusername.getText();
			if(password.contains("abc")&&username.contains("abc")) {
				txtpassword.setText(null);
				txtusername.setText(null);
				frame.dispose();
				homepage hp=new homepage();
				hp.setVisible(true);
				
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Invalid login details","Login error",JOptionPane.ERROR_MESSAGE);
				txtpassword.setText(null);
				txtusername.setText(null);
			}
			}
		});
		btnlogin.setBounds(152, 455, 117, 40);
		frame.getContentPane().add(btnlogin);
		
		JButton btnreset = new JButton("Reset");
		btnreset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			txtusername.setText(null);
			txtpassword.setText(null);
			}
		});
		btnreset.setBounds(341, 455, 114, 40);
		frame.getContentPane().add(btnreset);
		
		JButton btnexit = new JButton("Exit");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    frmloginsystem=new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmloginsystem, "Confirm if you want to exit.","Login System",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnexit.setBounds(517, 455, 117, 40);
		frame.getContentPane().add(btnexit);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk.jpg"));
		lblNewLabel.setBounds(0,0,700,600);
		frame.getContentPane().add(lblNewLabel);
	}
}
