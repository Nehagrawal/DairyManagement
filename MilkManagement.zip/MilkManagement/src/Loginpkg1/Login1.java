package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Login1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtusername;
	private JPasswordField txtpassword;
	private JFrame frmloginsystem;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login1 frame = new Login1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel lblUsername = new JLabel("User Name :");
		lblUsername.setBounds(212, 291, 104, 40);
	contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setBounds(212, 367, 104, 32);
		contentPane.add(lblPassword);
		
		txtusername = new JTextField();
		txtusername.setBounds(362, 302, 134, 19);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		JLabel lblLoginForm = new JLabel("Login Form");
		lblLoginForm.setBounds(302, 212, 104, 32);
		contentPane.add(lblLoginForm);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(373, 374, 133, 19);
		contentPane.add(txtpassword);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String password=txtpassword.getText();
			String username=txtusername.getText();
			if(password.contains("admin@123")&&username.contains("admin")) {
				txtpassword.setText(null);
				txtusername.setText(null);
				
				homepage hp=new homepage();
				hp.setVisible(true);
			
				
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Invalid login details","Login error",JOptionPane.ERROR_MESSAGE);
				txtpassword.setText(null);
				txtusername.setText(null);
			}
			}
		});
		btnlogin.setBounds(152, 455, 117, 40);
		contentPane.add(btnlogin);
		
		JButton btnreset = new JButton("Reset");
		btnreset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			txtusername.setText(null);
			txtpassword.setText(null);
			}
		});
		btnreset.setBounds(341, 455, 114, 40);
		contentPane.add(btnreset);
		
		JButton btnexit = new JButton("Exit");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    frmloginsystem=new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmloginsystem, "Confirm if you want to exit.","Login System",
						JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnexit.setBounds(517, 455, 117, 40);
		contentPane.add(btnexit);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk.jpg"));
		lblNewLabel.setBounds(0,0,700,600);
		contentPane.add(lblNewLabel);
		
	}

}
