package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

import java.sql.Statement;
import java.util.Vector;

public class ViewCustDetails extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	 myconnect my=new myconnect();
	    Connection conn = null;
	    Statement stat=null;
	    ResultSet rs;
	    final Vector columnNames=new Vector();
	    final Vector data=new Vector();
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewCustDetails frame = new ViewCustDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewCustDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,700, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		try {
		conn=my.getConn();
		
		String query="select * from Cust_Detail";
		stat=conn.createStatement();
		rs=stat.executeQuery(query);
		ResultSetMetaData md=rs.getMetaData();
		int column=md.getColumnCount();
		for(int i=1;i<=column;i++)
		{
			
			columnNames.addElement(md.getColumnName(i));
		}
		
		while(rs.next())
		{
			Vector row=new Vector(column);
			for(int i=1;i<=column;i++)
			{
				row.addElement(rs.getObject(i));
			}
			data.addElement(row);
		}
		}
		catch(Exception e) {}
		contentPane.setLayout(null);
		JTable table=new JTable(data,columnNames);
		table.setBackground(Color.WHITE);
		table.setFont(new Font("Dialog", Font.BOLD, 15));
		table.setForeground(Color.BLACK);
		
		
		 JTableHeader theader =table.getTableHeader();
		 theader.setBackground(Color.blue);
		 theader.setForeground(Color.white);
		 theader.setFont(new Font("Tanhoma",Font.BOLD,14));
		 table.setFont(new Font("Tanhoma",Font.BOLD,16));
		((DefaultTableCellRenderer)theader.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);
		JScrollPane scrollpane=new JScrollPane(table);
		scrollpane.setBounds(24, 62, 676, 566);
	    getContentPane().add(scrollpane);
	    
	  
	    
	    JLabel lblViewCustomerDetails = new JLabel("View Customer Details");
	    lblViewCustomerDetails.setFont(new Font("Dialog", Font.BOLD, 20));
	    lblViewCustomerDetails.setBounds(239, 34, 276, 16);
	    contentPane.add(lblViewCustomerDetails);
	 
	    JButton btnBack = new JButton("Back");
	    btnBack.setBackground(Color.GRAY);
	    btnBack.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		homepage hm=new homepage();
		        hm.setVisible(true);
		
	    	}
	    });
	    btnBack.setBounds(246, 659, 117, 25);
	    contentPane.add(btnBack);
	}

}
