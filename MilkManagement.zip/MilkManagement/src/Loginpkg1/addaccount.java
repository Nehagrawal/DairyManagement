package Loginpkg1;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.awt.event.ActionEvent;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Font;
import java.awt.Color;

public class addaccount extends JFrame {

	private JPanel contentPane;
	private JTextField cust_id;
	private JTextPane address;
	private JComboBox milk;
	
	private JTextField phone;
	JTextField cust_name;
    myconnect my=new myconnect();
    Connection conn = null;
	/**
	 * Launch the application.
	 */
   
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 addaccount frame=new addaccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addaccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel lblCustomerId = new JLabel("Customer ID");
		lblCustomerId.setBounds(114, 141, 127, 15);
		contentPane.add(lblCustomerId);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setBounds(113, 181, 138, 20);
		contentPane.add(lblCustomerName);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(114, 232, 70, 15);
		contentPane.add(lblAddress);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setBounds(114, 297, 115, 20);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblMilkCompany = new JLabel("Milk Company");
		lblMilkCompany.setBounds(115, 353, 101, 20);
		contentPane.add(lblMilkCompany);
		
		JLabel lblCattle = new JLabel("Cattle");
		lblCattle.setBounds(126, 413, 70, 15);
		contentPane.add(lblCattle);
		
		cust_id = new JTextField();
		cust_id.setBounds(320, 139, 114, 19);
		contentPane.add(cust_id);
		cust_id.setColumns(10);
		
	cust_name = new JTextField();
		cust_name.setBounds(320, 182, 114, 19);
		contentPane.add(cust_name);
		cust_name.setColumns(10);
		
		address = new JTextPane();
		address.setBounds(320, 232, 114, 56);
		contentPane.add(address);
		
		phone = new JTextField();
		phone.setBounds(320, 300, 114, 19);
		contentPane.add(phone);
		phone.setColumns(10);
		
		 milk = new JComboBox();
		 milk.addItem("Chitale");
		 milk.addItem("Gokul");
		
		
		milk.setBounds(320, 351, 114, 24);
		
		contentPane.add(milk);
		
		JRadioButton cow = new JRadioButton("Cow Milk");
		cow.setBounds(320, 409, 101, 23);
		contentPane.add(cow);
		
		JRadioButton buff = new JRadioButton("Buffelow Milk");
		buff.setBounds(433, 409, 127, 23);
		contentPane.add(buff);
	    ButtonGroup bg=new ButtonGroup();
	    bg.add(cow);
	    bg.add(buff);
	    
		JButton btnAdd = new JButton("Add");
		btnAdd.setBackground(Color.GRAY);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String query = "insert into Cust_Detail(Cust_id,Cust_name,Address,Phone_Number,Milk_Company,Cattle)"+"values(?,?,?,?,?,?)";
			
				try {	
				PreparedStatement prep_stmt;
				conn=my.getConn();
				prep_stmt = conn.prepareStatement(query);
				prep_stmt.setString(1,cust_id.getText());
				prep_stmt.setString(2,cust_name.getText());
				
				prep_stmt.setString(3, address.getText());
				prep_stmt.setString(4, phone.getText());
				String str=milk.getSelectedItem().toString();
				prep_stmt.setString(5, str); 
				String abc;
				if(cow.isSelected())
					
				{
					abc="cow";
				}
				else
				{
					abc="Buffelow";
				}
				prep_stmt.setString(6,abc );
				prep_stmt.executeUpdate();
				JOptionPane.showMessageDialog(null,"Registered Succesfully");
				conn.close();
			}catch(Exception e) {}
			}
		});
		btnAdd.setBounds(210, 466, 117, 25);
		contentPane.add(btnAdd);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
				
			}
		});
		btnBack.setBounds(393, 466, 117, 25);
		contentPane.add(btnBack);
		
		JLabel lblAddCustomerDetails = DefaultComponentFactory.getInstance().createTitle("Add Customer Details");
		lblAddCustomerDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddCustomerDetails.setBounds(149, 56, 285, 20);
		contentPane.add(lblAddCustomerDetails);
		
	
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel.setBounds(0, 0, 600, 650);
		contentPane.add(lblNewLabel);
	}
}
