package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import com.jgoodies.forms.factories.DefaultComponentFactory;

public class billing extends JFrame {

	private JPanel contentPane;
	private JTextField litter;
	 private JComboBox namecombo;
	 int li;
	 myconnect my=new myconnect();
	    Connection conn = null;
	    Statement stat=null;
	    ResultSet rs;
	    final Vector columnNames=new Vector();
	    final Vector data=new Vector();
	    private JTextField textField;
	    int total,ser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					billing frame = new billing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public  void dropdown()
	{
		try {
			 conn=my.getConn();
			 String name="select * from Cust_Detail";
			Statement stmt=(Statement) conn.createStatement();
			ResultSet set=stmt.executeQuery(name);
			while(set.next())
			{
				namecombo.addItem(set.getString("cust_name"));
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	
	
	
	public billing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 600,650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setForeground(Color.CYAN);
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel_2.setBounds(346, 328, 173, 24);
		contentPane.add(lblNewLabel_2);

		litter = new JTextField();
		litter.setBounds(346, 155, 114, 19);
		contentPane.add(litter);
		litter.setColumns(10);
		
		
		
		
		 namecombo = new JComboBox();
		/* namecombo.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 
		 		try {
		 			String fetch_row="select * from customer where name=?";
		 			PreparedStatement stmt=conn.prepareStatement(fetch_row);
		 			stmt.setString(1,(String)namecombo.getSelectedItem());
		 			ResultSet set=stmt.executeQuery();
		 		//	while(set.next())
		 			//{
		 				//lblNewLabel_2.setText(set.getString("litter"));
		 			//}
		 			
		 			 
		 			
		 			
					
				} catch (Exception e) {
					// TODO: handle exception
				}
		 		
		 	}
		 });
		 */
		namecombo.setBounds(346, 101, 123, 24);
		contentPane.add(namecombo);
		
		JLabel lblNewLabel = new JLabel("Select Customer Name");
		lblNewLabel.setBounds(65, 106, 199, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(" Litter");
		lblNewLabel_1.setBounds(71, 157, 160, 15);
		contentPane.add(lblNewLabel_1);
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setForeground(Color.CYAN);
		lblNewLabel_3.setBounds(346, 210, 125, 32);
		contentPane.add(lblNewLabel_3);
		JTextField servicecharge = new JTextField();
		servicecharge.setBounds(346, 254, 123, 19);
		contentPane.add(servicecharge);
		servicecharge.setColumns(10);
		
		
		
		JButton btnCalculateBill = new JButton("Calculate  Bill");
		btnCalculateBill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				ser=Integer.parseInt(servicecharge.getText());
				total=li+ser;
				lblNewLabel_2 .setText(Integer.toString(total));
			}
		});
		btnCalculateBill.setBounds(83, 302, 141, 25);
		contentPane.add(btnCalculateBill);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBackground(Color.GRAY);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String query = "insert into billing(Name,Litter,Service_Charge ,Total)"+"values(?,?,?,?)";
				
				try {	
				PreparedStatement prep_stmt;
				conn=my.getConn();
				prep_stmt = conn.prepareStatement(query);
				String str=namecombo.getSelectedItem().toString();
				prep_stmt.setString(1, str); 
				prep_stmt.setString(2,litter.getText()); 
				prep_stmt.setString(3,servicecharge.getText()); 
				
				prep_stmt.setString(4,Integer.toString(li));
				prep_stmt.executeUpdate();
				
				JOptionPane.showMessageDialog(null,"Added Succesfully");
				conn.close();
			}catch(Exception e) {}
				
			}
		});
		btnAdd.setBounds(150, 374, 117, 25);
		contentPane.add(btnAdd);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
			}
		});
		btnBack.setBounds(374, 374, 117, 25);
		contentPane.add(btnBack);
		
				JButton btnWithoutServiceCharge = new JButton("without service charge");
				btnWithoutServiceCharge.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						 li=Integer.parseInt(litter.getText());
							li=li*30;
						lblNewLabel_3.setText(Integer.toString(li));
						
					}
				});
				btnWithoutServiceCharge.setBounds(71, 205, 196, 25);
				contentPane.add(btnWithoutServiceCharge);
		
		JLabel lblServiceCharge = new JLabel("Service Charge");
		lblServiceCharge.setBounds(94, 256, 106, 15);
		contentPane.add(lblServiceCharge);
		
		JLabel lblBillDetails = DefaultComponentFactory.getInstance().createTitle("Bill Details");
		lblBillDetails.setFont(new Font("Dialog", Font.BOLD, 30));
		lblBillDetails.setForeground(Color.BLACK);
		lblBillDetails.setBounds(226, 45, 199, 24);
		contentPane.add(lblBillDetails);
		
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel1.setBounds(0, 0, 600, 570);
		contentPane.add(lblNewLabel1);
		
	
		
		dropdown();
	}
}
