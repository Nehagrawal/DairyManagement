package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class deleteaccount extends JFrame {

	private JPanel contentPane;
	private JTextField custid;
	myconnect my=new myconnect();
    Connection conn = null;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deleteaccount frame = new deleteaccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deleteaccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCustomerId = new JLabel("Customer ID");
		lblCustomerId.setBounds(163, 123, 112, 15);
		contentPane.add(lblCustomerId);
		
		custid = new JTextField();
		custid.setBounds(343, 123, 114, 19);
		contentPane.add(custid);
		custid.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBackground(Color.GRAY);
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					PreparedStatement prep = null;
					conn=my.getConn();
				String sql="delete from Cust_Detail  where Cust_id=?";
				prep=conn.prepareStatement(sql);
				prep.setString(1,custid.getText());

				prep.execute();
				
				
			JOptionPane.showMessageDialog(null,"Delete Succesfully");
			conn.close();
		}catch(Exception e) {}
			}
		});
		btnDelete.setBounds(172, 175, 117, 25);
		contentPane.add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
		        
			}
		});
		btnBack.setBounds(353, 175, 117, 25);
		contentPane.add(btnBack);
		
		JLabel lblAddCustomerDetails = DefaultComponentFactory.getInstance().createTitle("Delete Customer Details");
		lblAddCustomerDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddCustomerDetails.setBounds(134, 74, 330, 20);
		contentPane.add(lblAddCustomerDetails);
		

		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel1.setBounds(0, 0, 600, 650);
		contentPane.add(lblNewLabel1);
	}
}
