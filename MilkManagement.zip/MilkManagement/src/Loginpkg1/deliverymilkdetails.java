package Loginpkg1;


import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import com.jgoodies.forms.factories.DefaultComponentFactory;
import com.toedter.calendar.JDateChooser;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;

public class deliverymilkdetails extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
    myconnect my=new myconnect();
    Connection conn = null;
    private JTextField Name;
    private JTextField litter;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deliverymilkdetails frame = new deliverymilkdetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deliverymilkdetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCustId = new JLabel("Cust Name");
		lblCustId.setBounds(125, 136, 114, 15);
		contentPane.add(lblCustId);
		
		
		
		
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setBounds(135, 184, 70, 15);
		contentPane.add(lblDate);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("yyyy-MM-dd");
		dateChooser.setBounds(313, 180, 100, 19);
		contentPane.add(dateChooser);
		
		JLabel lblMilkCompany = new JLabel("Milk Company");
		
		lblMilkCompany.setBounds(127, 233, 100, 15);
		contentPane.add(lblMilkCompany);
		
		JComboBox milk;
		 milk = new JComboBox();
		 milk.addItem("Chitale");
		 milk.addItem("Gokul");
		
		
		milk.setBounds(313, 233, 114, 24);
		
		contentPane.add(milk);
		
		
		
		JLabel lblCattle = new JLabel("Cattle");
		lblCattle.setBounds(135, 274, 70, 15);
		contentPane.add(lblCattle);
		
		JRadioButton cow = new JRadioButton("Cow");
		cow.setBounds(313, 288, 100, 23);
		contentPane.add(cow);
		
		JRadioButton buff = new JRadioButton("buffelow");
		buff.setBounds(421, 287, 114, 24);
		contentPane.add(buff);
		 ButtonGroup bg=new ButtonGroup();
		    bg.add(cow);
		    bg.add(buff);
		    
		    JLabel lbllitter = new JLabel("Litter");
		    lbllitter.setBounds(135, 333, 70, 15);
			contentPane.add(lbllitter);
			Name = new JTextField();
			Name.setBounds(313, 134, 114, 19);
			contentPane.add(Name);
			Name.setColumns(10);
			
			litter = new JTextField();
			litter.setBounds(313, 328, 114, 19);
			contentPane.add(litter);
			litter.setColumns(10);
			
			
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBackground(Color.GRAY);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String query = "insert into customer(name,date,milk,cattle,litter)"+"values(?,?,?,?,?)";
			
				try {	
				PreparedStatement prep_stmt;
				conn=my.getConn();
				prep_stmt = conn.prepareStatement(query);
				prep_stmt.setString(1,Name.getText());
				prep_stmt.setString(2,((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());
				
				String str=milk.getSelectedItem().toString();
				prep_stmt.setString(3, str); 
				
				String abc;
				if(cow.isSelected())
				{
					abc="cow";
				}
				else
				{
					abc="Buffelow";
				}
				prep_stmt.setString(4,abc );
				
				prep_stmt.setString(5,litter.getText());
			System.out.println("aftr 5");
			prep_stmt.executeUpdate();
			System.out.println("aftr 6");
				JOptionPane.showMessageDialog(null,"Added Succesfully");
				conn.close();
				}catch(Exception e) {}
			}
		});
		
		btnAdd.setBounds(191, 407, 117, 25);
		contentPane.add(btnAdd);
		
		
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
		      
			}
		});
		btnBack.setBounds(394, 407, 117, 25);
		contentPane.add(btnBack);
		
		JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("Cutomer Daily Delivery Details");
		lblNewJgoodiesTitle.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewJgoodiesTitle.setBounds(125, 58, 386, 40);
		contentPane.add(lblNewJgoodiesTitle);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		label.setBounds(0, 0, 600, 650);
		contentPane.add(label);
		
		
		
		
	}
}
