package Loginpkg1;
import java.sql.*;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.sql.Statement;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class displaybill extends JFrame {

	private JPanel contentPane;
	 myconnect my=new myconnect();
	    Connection conn = null;
	    Statement stat=null;
	    ResultSet rs;
	    final Vector columnNames=new Vector();
	    final Vector data=new Vector();
	    private JTextField textField;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					displaybill frame = new displaybill();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public displaybill() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		

		try {
		conn=my.getConn();
		
		String query="select * from billing";
		stat=(Statement) conn.createStatement();
		rs=stat.executeQuery(query);
		ResultSetMetaData md=rs.getMetaData();
		int column=md.getColumnCount();
		for(int i=1;i<=column;i++)
		{
			
			columnNames.addElement(md.getColumnName(i));
		}
		
		while(rs.next())
		{
			Vector row=new Vector(column);
			for(int i=1;i<=column;i++)
			{
				row.addElement(rs.getObject(i));
			}
			data.addElement(row);
		}
		}
		catch(Exception e) {}
		contentPane.setLayout(null);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
		      
			}
		});
		btnNewButton.setBounds(226, 574, 117, 25);
		contentPane.add(btnNewButton);
		
		JTable table=new JTable(data,columnNames);
		table.setBackground(Color.WHITE);
		table.setFont(new Font("Dialog", Font.BOLD, 15));
		table.setForeground(Color.BLACK);
		
		JScrollPane scrollpane=new JScrollPane(table);
		scrollpane.setBounds(12, 83, 576, 555);
	    getContentPane().add(scrollpane);
		
		
		 JTableHeader theader =table.getTableHeader();
		
		JLabel lblCustomerBillDetails = new JLabel("Customer Bill Details");
		lblCustomerBillDetails.setFont(new Font("Dialog", Font.BOLD, 20));
		lblCustomerBillDetails.setBounds(159, 28, 278, 25);
		contentPane.add(lblCustomerBillDetails);
		 theader.setBackground(Color.blue);
		 theader.setForeground(Color.white);
	
		 theader.setFont(new Font("Tanhoma",Font.BOLD,14));
		((DefaultTableCellRenderer)theader.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

		
	}
}
