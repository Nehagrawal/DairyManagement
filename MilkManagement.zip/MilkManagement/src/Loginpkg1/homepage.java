package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;

public class homepage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	static homepage frame = new homepage();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public homepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 600,650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.LIGHT_GRAY);
		menuBar.setForeground(new Color(192, 192, 192));
		menuBar.setBounds(0, 0, 624, 25);
		contentPane.add(menuBar);
		
		JMenu mnHome = new JMenu("Home");
		mnHome.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		menuBar.add(mnHome);
		
		
		JMenu mnAccounts = new JMenu("Accounts");
		mnAccounts.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		menuBar.add(mnAccounts);
		
		
		JMenuItem mntmAddAccount = new JMenuItem("Add Account");
		mntmAddAccount.setFont(new Font("Serif", Font.BOLD, 14));
		mntmAddAccount.setForeground(new Color(30, 144, 255));
		mntmAddAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				addaccount adac=new addaccount();
				adac.setVisible(true);
				setVisible(false);								
			}
		});
		mnAccounts.add(mntmAddAccount);
		
		
		JMenuItem mntmUpdateAccount = new JMenuItem("Update Account");
		mntmUpdateAccount.setFont(new Font("Serif", Font.BOLD, 14));
		mntmUpdateAccount.setForeground(new Color(30, 144, 255));
		mntmUpdateAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateaccount up=new updateaccount();
				up.setVisible(true);
				setVisible(false);
			}
		});
		mnAccounts.add(mntmUpdateAccount);
		
		JMenuItem mntmDeleteAccount = new JMenuItem("Delete Account");
		mntmDeleteAccount.setFont(new Font("Serif", Font.BOLD, 14));
		mntmDeleteAccount.setForeground(new Color(30, 144, 255));
		
		mntmDeleteAccount.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				deleteaccount da=new deleteaccount();
				da.setVisible(true);
				setVisible(false);
			}
		});
		mnAccounts.add(mntmDeleteAccount);
		
		JMenuItem mntmViewAccount = new JMenuItem("View Account");
		mntmViewAccount.setFont(new Font("Serif", Font.BOLD, 14));
		mntmViewAccount.setForeground(new Color(30, 144, 255));
		mntmViewAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ViewCustDetails vd=new ViewCustDetails();
				vd.setVisible(true);
			
				
			}
		});
		mnAccounts.add(mntmViewAccount);
		
		JMenu mnBilling = new JMenu("Billing");
		mnBilling.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		menuBar.add(mnBilling);
		
		JMenuItem mntmbill= new JMenuItem("Bill");
		mntmbill.setFont(new Font("Serif", Font.BOLD, 14));
		mntmbill.setForeground(new Color(30, 144, 255));
		mntmbill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				billing ch=new billing();
				ch.setVisible(true);
				setVisible(false);
			}
		});
		
		mnBilling.add(mntmbill);
		
		JMenuItem mntmdisp= new JMenuItem("Display Bill");
		mntmdisp.setFont(new Font("Serif", Font.BOLD, 14));
		mntmdisp.setForeground(new Color(30, 144, 255));
		mntmdisp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				displaybill ch=new displaybill();
				ch.setVisible(true);
			}
		});
		
		mnBilling.add(mntmdisp);
		
		
		JMenu mnHelp = new JMenu("Company Details");
		mnHelp.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		menuBar.add(mnHelp);
		
		
				
	
		
		JMenuItem mntmChitale = new JMenuItem("Chitale");
		mntmChitale.setFont(new Font("Serif", Font.BOLD, 14));
		mntmChitale.setForeground(new Color(30, 144, 255));
		mntmChitale.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Chitale ch=new Chitale();
				ch.setVisible(true);
			}
		});
		
		mnHelp.add(mntmChitale);
		
		JMenuItem mntmGokul = new JMenuItem("Gokul");
		mntmGokul.setFont(new Font("Serif", Font.BOLD, 14));
		mntmGokul.setForeground(new Color(30, 144, 255));
		mntmGokul.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Gokul gk=new Gokul();
				gk.setVisible(true);
			}
		});
		mnHelp.add(mntmGokul);
		
		JMenu mndev = new JMenu("Delivery Details");
		mndev.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		menuBar.add(mndev);
		JMenuItem mntmdaily = new JMenuItem("Daily delivery");
		mntmdaily.setFont(new Font("Serif", Font.BOLD, 14));
		mntmdaily.setForeground(new Color(30, 144, 255));
		mntmdaily.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deliverymilkdetails d=new deliverymilkdetails();
				d.setVisible(true);
			}
		});

		mndev.add(mntmdaily);
		
		JMenuItem mntmview = new JMenuItem("View Daily delivery");
		mntmview.setFont(new Font("Serif", Font.BOLD, 14));
		mntmview.setForeground(new Color(30, 144, 255));
		mntmview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				viewdailydelivery v=new viewdailydelivery();
				v.setVisible(true);
			}
		});

		mndev.add(mntmview);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Century Schoolbook L", Font.BOLD, 16));
		lblNewLabel.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel.setBounds(10, 0, 700, 570);
		contentPane.add(lblNewLabel);
			}
}