package Loginpkg1;

import java.sql.*;
import java.io.*;

public class myconnect {

	  final String DB_URL;
	  final String USER;
	 final String PASS;
		// TODO Auto-generated method stub
		 
		 public myconnect()
		 {
			  DB_URL = "jdbc:mysql://localhost:3306/dbms?useSSL=false";
			 USER = "dbms";
			  PASS = "Dbms@123#";
		 }
			
		 
	   public Connection getConn()throws IOException, ClassNotFoundException, SQLException
	   {
			Connection conn = null;
			Statement stmt = null;
			//char c='y';
			
			int n;
			try{
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("connecting to the database");
					
					conn = DriverManager.getConnection(DB_URL,USER,PASS);
					stmt = conn.createStatement();
					
					
					
			}catch(Exception e) {}
			return conn;   
	   
	  } 

}
