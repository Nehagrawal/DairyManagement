package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;

public class updateaccount extends JFrame {

	private JPanel contentPane;
	private JTextField custname;

	private JTextField custid;
	private JTextPane address;
	private JComboBox milk;

	private JTextField ph;
	JTextPane textPane;

	 myconnect my=new myconnect();
	    Connection conn = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updateaccount frame = new updateaccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public updateaccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50,600, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel cust_id = new JLabel("Customer ID");
		cust_id.setBounds(116, 171, 140, 15);
		contentPane.add(cust_id);
		
		JLabel firstname = new JLabel("Customer Name");
		firstname.setBounds(116, 216, 117, 15);
		contentPane.add(firstname);
		
		
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(134, 274, 84, 15);
		contentPane.add(lblAddress);
		
		custid = new JTextField();
		custid.setBounds(326, 169, 114, 19);
		contentPane.add(custid);
		custid.setColumns(10);
		
		custname = new JTextField();
		custname.setBounds(326, 214, 114, 19);
		contentPane.add(custname);
		custname.setColumns(10);
		
		
		
		textPane = new JTextPane();
		textPane.setBounds(326, 274, 114, 63);
		contentPane.add(textPane);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setBounds(134, 374, 104, 15);
		contentPane.add(lblPhoneNumber);
		
		JLabel lblMilkCompany = new JLabel("Milk Company");
		lblMilkCompany.setBounds(134, 434, 104, 15);
		contentPane.add(lblMilkCompany);
		
		JLabel lblCattle = new JLabel("Cattle");
		lblCattle.setBounds(157, 483, 70, 15);
		contentPane.add(lblCattle);
		
		JRadioButton buff = new JRadioButton("Buffelow");
		buff.setBounds(411, 479, 104, 23);
		contentPane.add(buff);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage hm=new homepage();
		        hm.setVisible(true);
		 
			}
		});
		btnBack.setBounds(361, 561, 117, 25);
		contentPane.add(btnBack);
		
		ph = new JTextField();
		ph.setBounds(326, 372, 114, 19);
		contentPane.add(ph);
		ph.setColumns(10);
		
		 milk = new JComboBox();
		 
		 milk.addItem("Chitale");
		 milk.addItem("Gokul");
				milk.setBounds(326, 429, 84, 24);
		contentPane.add(milk);
		
		JRadioButton cow = new JRadioButton("Cow");
		cow.setBounds(300, 479, 91, 23);
		contentPane.add(cow);
		 ButtonGroup bg=new ButtonGroup();
		    bg.add(cow);
		
		    
		   
		    
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBackground(Color.GRAY);
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
						
				try {
					PreparedStatement prep = null;
					conn=my.getConn();
					String cust_id=custid.getText();
					String cust_name=custname.getText();
					String address=textPane.getText();
					
					String phone=ph.getText();
					String str=milk.getSelectedItem().toString();
					
					String abc;
					if(cow.isSelected())
					{
						abc="cow";
					}
					else
					{
						abc="Buffelow";
					}
					String sql="update Cust_Detail set Cust_id='"+cust_id+"',Cust_name='"+cust_name+"',Address='"+address+"',Phone_Number='"+phone+"', Milk_Company='"+str+"',Cattle='"+abc+"' where Cust_id='"+custid.getText()+"'";
					prep=conn.prepareStatement(sql);
					prep.execute();
					
					
				JOptionPane.showMessageDialog(null,"Update Succesfully");
				conn.close();
			}catch(Exception e) {}
			}
		});
		btnUpdate.setBounds(172, 561, 117, 25);
		contentPane.add(btnUpdate);
		JLabel lblAddCustomerDetails = DefaultComponentFactory.getInstance().createTitle("Update Customer Details");
		lblAddCustomerDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddCustomerDetails.setBounds(134, 74, 330, 20);
		contentPane.add(lblAddCustomerDetails);
		

		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setIcon(new ImageIcon("/home/hp/My Desktop/desktop/Downloads/milk-splash_23-2147507026.jpg"));
		lblNewLabel1.setBounds(0, 0, 600, 650);
		contentPane.add(lblNewLabel1);
		
		
		
	}
}
