package Loginpkg1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class viewdailydelivery extends JFrame {

	private JPanel contentPane;
	 myconnect my=new myconnect();
	    Connection conn = null;
	    Statement stat=null;
	    ResultSet rs;
	    final Vector columnNames=new Vector();
	    final Vector data=new Vector();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewdailydelivery frame = new viewdailydelivery();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public viewdailydelivery() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50,50,600,650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		try {
			conn=my.getConn();
			
			String query="select * from customer order by name";
			stat=conn.createStatement();
			rs=stat.executeQuery(query);
			ResultSetMetaData md=rs.getMetaData();
			int column=md.getColumnCount();
			for(int i=1;i<=column;i++)
			{
				
				columnNames.addElement(md.getColumnName(i));
			}
			
			while(rs.next())
			{
				Vector row=new Vector(column);
				for(int i=1;i<=column;i++)
				{
					row.addElement(rs.getObject(i));
				}
				data.addElement(row);
			}
			}
			catch(Exception e) {}
			contentPane.setLayout(null);
			contentPane.setLayout(null);
			
			JButton btnNewButton = new JButton("Back");
			btnNewButton.setBackground(Color.GRAY);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					homepage hm=new homepage();
			        hm.setVisible(true);
			        
				}
			});
			btnNewButton.setBounds(237, 565, 117, 25);
			contentPane.add(btnNewButton);
			JTable table=new JTable(data,columnNames);
			table.setBackground(Color.WHITE);
			table.setFont(new Font("Dialog", Font.BOLD, 15));
			table.setForeground(Color.BLACK);
			
			JScrollPane scrollpane=new JScrollPane(table);
			scrollpane.setBounds(12, 29, 588, 609);
		    getContentPane().add(scrollpane);
			
			
			 JTableHeader theader =table.getTableHeader();
			 theader.setBackground(Color.blue);
			 theader.setForeground(Color.white);
			 theader.setFont(new Font("Tanhoma",Font.BOLD,14));
			((DefaultTableCellRenderer)theader.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);
	}

}
